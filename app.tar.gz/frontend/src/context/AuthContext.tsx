'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

import { useRouter } from 'next/navigation';

interface Role {
    id: number;
    store_slug: string;
    store_name: string;
    role: 'owner' | 'manager' | 'waiter' | 'kitchen' | 'driver';
}

interface User {
    username: string;
    email: string;
    first_name: string;
    roles: Role[];
}

interface AuthContextType {
    user: User | null;
    login: (token: string) => Promise<void>;
    logout: () => void;
    loading: boolean;
    refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    const fetchUser = async (token: string) => {
        try {
            const response = await fetch('/api/users/me/', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (response.ok) {
                const userData = await response.json();
                setUser(userData);
                localStorage.setItem('user', JSON.stringify(userData));

                // Also set activeStoreId if not set, taking the first role's store
                if (!localStorage.getItem('activeStoreId') && userData.roles?.length > 0) {
                    const firstStoreId = userData.roles[0]?.id;
                    if (firstStoreId) {
                        localStorage.setItem('activeStoreId', String(firstStoreId));
                    }
                }

                return userData;
            } else {
                logout();
            }
        } catch (error) {
            console.error('Error fetching user:', error);
            logout();
        }
    };

    useEffect(() => {
        const storedUser = localStorage.getItem('user');
        const token = localStorage.getItem('token');
        if (storedUser && token) {
            setUser(JSON.parse(storedUser));
            // Validate/Refresh user data in background
            fetchUser(token);
        }
        setLoading(false);
    }, []);

    const login = async (token: string) => {
        setLoading(true);
        localStorage.setItem('token', token);
        await fetchUser(token);
        setLoading(false);
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
        localStorage.removeItem('activeStoreId');
        router.push('/login');
    };

    const refreshUser = async () => {
        const token = localStorage.getItem('token');
        if (token) {
            await fetchUser(token);
        }
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading, refreshUser }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
